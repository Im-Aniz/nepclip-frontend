from django.db import IntegrityError, transaction
from django.utils import timezone
from rest_framework.exceptions import ValidationError

from apps.analytics.platforms.base import PlatformError, PlatformNotConfigured
from apps.analytics.platforms.registry import get_client
from apps.analytics.services.sync import record_snapshot
from apps.campaigns.models import CampaignCreator
from apps.campaigns.services.context import eligibility_for
from apps.fraud.services.evaluate import evaluate_submission
from apps.submissions.models import Submission
from apps.submissions.services.quality import evaluate_quality


def create_submission(user, campaign, data):
    """Validates everything listed in the spec, then creates the submission, first snapshot and fraud score."""
    today = timezone.localdate()
    platform = data["platform"]
    if not campaign.is_open(today):
        raise ValidationError({"detail": "This campaign is not open."})
    if today > campaign.deadline:
        raise ValidationError({"detail": "The submission deadline has passed."})
    if not CampaignCreator.objects.filter(campaign=campaign, creator=user, status="active").exists():
        raise ValidationError({"detail": "Join the campaign before submitting."})
    if platform not in [p.platform for p in campaign.platforms.all()]:
        raise ValidationError({"platform": "This campaign doesn't accept that platform."})

    client = get_client(platform)
    post_id = client.parse_post_url(data["url"])
    if not post_id:
        raise ValidationError({"url": f"That doesn't look like a valid {platform.title()} post URL."})

    elig = eligibility_for(user, campaign)
    if not elig.eligible:
        raise ValidationError({"detail": "You no longer meet this campaign's requirements.", "reasons": elig.reasons})
    accounts = [a for a in user.social_accounts.filter(platform=platform, status="connected")]
    if not accounts:
        raise ValidationError({"detail": f"Connect and verify a {platform.title()} account first."})
    account = next((a for a in accounts if a.id == data.get("social_account")), None) or \
        next((a for a in accounts if a.id == elig.matched_account_id), accounts[0])

    live = Submission.objects.filter(campaign=campaign, creator=user).exclude(status="rejected").count()
    if live >= campaign.max_submissions_per_creator:
        raise ValidationError({"detail": f"Submission limit reached ({campaign.max_submissions_per_creator})."})
    if Submission.objects.filter(campaign=campaign, platform=platform, external_post_id=post_id).exists():
        raise ValidationError({"url": "This video has already been submitted to this campaign."})

    meta, flags, verified = None, [], False
    try:
        meta = client.fetch_posts_for_account(account, [post_id]).get(post_id)
        verified = True
    except PlatformNotConfigured:
        flags.append({"code": "unverified", "message": "Automatic verification unavailable; a reviewer will check ownership and rules.", "action": "flag"})
    except PlatformError as e:
        raise ValidationError({"detail": f"Couldn't read that post right now: {e}"})

    if meta is not None:
        if not meta.available:
            raise ValidationError({"url": "That post is deleted or private. Make it public and try again."})
        if meta.channel_id and meta.channel_id != account.external_id:
            raise ValidationError({"url": "This video doesn't belong to your connected account."})
        if meta.posted_at and meta.posted_at.date() < campaign.start_date:
            raise ValidationError({"url": "The video must be published after the campaign start date."})
        vio = evaluate_quality(campaign.rules, meta, data.get("caption", ""))
        hard = [v for v in vio if v.action == "reject"]
        if hard:
            raise ValidationError({"detail": "Your clip doesn't meet the campaign rules.", "violations": [v.message for v in hard]})
        flags += [{"code": v.code, "message": v.message, "action": v.action} for v in vio]

    try:
        with transaction.atomic():
            sub = Submission.objects.create(
                campaign=campaign, creator=user, social_account=account, platform=platform, url=data["url"],
                external_post_id=post_id, caption=data.get("caption", ""), notes=data.get("notes", ""),
                quality_flags=flags, status=Submission.Status.UNDER_REVIEW if flags else Submission.Status.PENDING,
                metadata={"title": meta.title, "duration": meta.duration_seconds,
                          "posted_at": meta.posted_at.isoformat() if meta.posted_at else None} if meta else {})
            if meta is not None:
                record_snapshot(sub, meta)
            evaluate_submission(sub)
            if verified and not flags and campaign.auto_approve and sub.status == Submission.Status.PENDING:
                from apps.submissions.services.review import review_submission
                review_submission(sub, None, "approved", "Auto-approved: passed all automatic checks")
    except IntegrityError:
        raise ValidationError({"url": "This video has already been submitted to this campaign."})
    sub.refresh_from_db()
    return sub
