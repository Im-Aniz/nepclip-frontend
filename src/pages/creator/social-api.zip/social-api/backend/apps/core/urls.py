from django.urls import include, path
from rest_framework.routers import DefaultRouter

from apps.adminpanel import public_views as pv
from apps.adminpanel import views as av
from apps.analytics.views import LeaderboardView, PerformanceView
from apps.campaigns.views import CampaignViewSet
from apps.creators import oauth as social_oauth
from apps.creators.views import SocialAccountViewSet
from apps.earnings.views import EarningListView
from apps.notifications import views as nv
from apps.referrals.views import ReferralView
from apps.submissions.views import MySubmissionViewSet
from apps.support import views as sv
from apps.wallets.views import TransactionListView, WalletView, WithdrawalViewSet

router = DefaultRouter()
router.register("campaigns", CampaignViewSet, basename="campaign")
router.register("social-accounts", SocialAccountViewSet, basename="social-account")
router.register("submissions", MySubmissionViewSet, basename="submission")
router.register("withdrawals", WithdrawalViewSet, basename="withdrawal")
router.register("reports", pv.MyReportViewSet, basename="report")

admin_router = DefaultRouter()
admin_router.register("users", av.AdminUserViewSet, basename="admin-user")
admin_router.register("campaigns", av.AdminCampaignViewSet, basename="admin-campaign")
admin_router.register("submissions", av.AdminSubmissionViewSet, basename="admin-submission")
admin_router.register("withdrawals", av.AdminWithdrawalViewSet, basename="admin-withdrawal")
admin_router.register("transactions", av.AdminTransactionViewSet, basename="admin-transaction")
admin_router.register("inquiries", av.AdminInquiryViewSet, basename="admin-inquiry")
admin_router.register("reports", av.AdminReportViewSet, basename="admin-report")
admin_router.register("audit-logs", av.AdminAuditLogViewSet, basename="admin-audit")

urlpatterns = [
    path("auth/", include("apps.accounts.urls")),
    path("creators/", include("apps.creators.urls")),
    path("social-oauth/<str:platform>/start/", social_oauth.oauth_start),
    path("social-oauth/<str:platform>/callback/", social_oauth.oauth_callback),
    path("brands/", include("apps.brands.urls")),
    path("performance/", PerformanceView.as_view()),
    path("earnings/", EarningListView.as_view()),
    path("wallet/", WalletView.as_view()),
    path("wallet/transactions/", TransactionListView.as_view()),
    path("referrals/", ReferralView.as_view()),
    path("notifications/", nv.NotificationListView.as_view()),
    path("notifications/read-all/", nv.mark_all_read),
    path("notifications/<int:pk>/read/", nv.mark_read),
    path("leaderboard/", LeaderboardView.as_view()),
    path("public/settings/", pv.PublicSettingsView.as_view()),
    path("public/stats/", pv.PublicStatsView.as_view()),
    path("inquiries/", pv.InquiryCreateView.as_view()),
    path("admin/dashboard/", av.dashboard),
    path("admin/settings/", av.platform_settings),
    path("admin/referrals/", av.referrals_overview),
    path("admin/fraud/", av.fraud_overview),
    path("admin/social-accounts/", av.social_accounts_admin),
    path("admin/notifications/broadcast/", av.broadcast),
    path("support/chat/", sv.UserChatView.as_view()),
    path("admin/support/unread/", sv.AdminUnreadView.as_view()),
    path("admin/support/threads/", sv.AdminThreadListView.as_view()),
    path("admin/support/threads/<int:pk>/", sv.AdminThreadView.as_view()),
    path("admin/support/threads/<int:pk>/status/", sv.AdminThreadStatusView.as_view()),
    path("admin/", include(admin_router.urls)),
    path("", include(router.urls)),
]
