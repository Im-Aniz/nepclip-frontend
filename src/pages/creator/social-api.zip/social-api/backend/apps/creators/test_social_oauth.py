from datetime import timedelta
from unittest import mock

from django.core import signing
from django.test import TestCase, override_settings
from django.utils import timezone
from rest_framework.test import APIClient

from apps.accounts.models import User
from apps.analytics.platforms.base import PlatformError, TokenSet
from apps.analytics.platforms.instagram import InstagramClient
from apps.analytics.platforms.registry import get_client
from apps.analytics.platforms.tiktok import TikTokClient
from apps.analytics.services.tokens import access_token_for
from apps.creators.models import SocialAccount, SocialToken

KEYS = dict(TIKTOK_CLIENT_KEY="ck", TIKTOK_CLIENT_SECRET="cs", INSTAGRAM_APP_ID="ia", INSTAGRAM_APP_SECRET="is")


class Resp:
    def __init__(self, body, status=200):
        self._b, self.status_code = body, status

    def json(self):
        return self._b


@override_settings(**KEYS)
class AdapterTests(TestCase):
    def test_tiktok_posts(self):
        body = {"data": {"videos": [{"id": "111", "title": "t", "video_description": "hi #Funny #nep", "duration": 30, "view_count": 1000,
                                     "like_count": 50, "comment_count": 5, "share_count": 2, "create_time": 1760000000}]}, "error": {"code": "ok"}}
        with mock.patch("requests.request", return_value=Resp(body)) as m:
            out = TikTokClient().fetch_posts_with_token("tok", "open1", ["111", "222"])
        self.assertEqual(out["111"].views, 1000)
        self.assertEqual(out["111"].tags, ["funny", "nep"])
        self.assertEqual(out["111"].channel_id, "open1")
        self.assertFalse(out["222"].available)                       # not returned = not owned / deleted
        self.assertEqual(m.call_args.kwargs["json"], {"filters": {"video_ids": ["111", "222"]}})

    def test_tiktok_error_shapes(self):
        with mock.patch("requests.request", return_value=Resp({"error": {"code": "access_token_invalid", "message": "bad token"}})):
            with self.assertRaises(PlatformError):
                TikTokClient().fetch_posts_with_token("t", "o", ["1"])
        with mock.patch("requests.request", return_value=Resp({"error": "invalid_grant", "error_description": "code used"}, 400)):
            with self.assertRaises(PlatformError):
                TikTokClient().exchange_code("x")

    def test_tiktok_url(self):
        c = TikTokClient()
        self.assertEqual(c.parse_post_url("https://www.tiktok.com/@some.one/video/7301234567890123456?is_from_webapp=1"), "7301234567890123456")
        self.assertIsNone(c.parse_post_url("https://example.com/@a/video/1"))

    def test_instagram_posts(self):
        def fake(method, url, **kw):
            if url.endswith("/me/media"):
                return Resp({"data": [{"id": "900", "permalink": "https://www.instagram.com/reel/ABC123/", "caption": "yo #Nep", "like_count": 10,
                                       "comments_count": 2, "media_product_type": "REELS", "timestamp": "2026-10-01T10:00:00+0000"}]})
            if "/insights" in url:
                return Resp({"data": [{"name": "views", "values": [{"value": 4321}]}, {"name": "shares", "values": [{"value": 7}]}]})
            raise AssertionError(url)
        with mock.patch("requests.request", side_effect=fake):
            out = InstagramClient().fetch_posts_with_token("tok", "ig1", ["ABC123", "ZZZ999"])
        a = out["ABC123"]
        self.assertEqual((a.views, a.likes, a.comments, a.shares, a.channel_id, a.is_vertical), (4321, 10, 2, 7, "ig1", True))
        self.assertEqual(a.tags, ["nep"])
        self.assertIsNotNone(a.posted_at)
        self.assertFalse(out["ZZZ999"].available)

    def test_instagram_url(self):
        c = InstagramClient()
        self.assertEqual(c.parse_post_url("https://www.instagram.com/reel/ABC123/?igsh=x"), "ABC123")
        self.assertEqual(c.parse_post_url("https://www.instagram.com/someone/p/Xy_-9/"), "Xy_-9")

    def test_registry_and_unconfigured(self):
        self.assertTrue(get_client("tiktok").oauth and get_client("instagram").oauth)
        self.assertFalse(get_client("youtube").oauth)


@override_settings(**KEYS)
class FlowTests(TestCase):
    def setUp(self):
        self.user = User.objects.create_user(email="c@x.com", username="cre", password="pass12345!", role="creator")

    def test_start_requires_config_and_returns_url(self):
        api = APIClient()
        api.force_authenticate(self.user)
        with mock.patch("apps.creators.oauth.get_setting", return_value=["youtube", "tiktok", "instagram"]):
            r = api.get("/api/social-oauth/tiktok/start/")
            self.assertEqual(r.status_code, 200)
            self.assertIn("client_key=ck", r.data["url"])
            self.assertIn("state=", r.data["url"])
            self.assertEqual(api.get("/api/social-oauth/youtube/start/").status_code, 404)
            with override_settings(INSTAGRAM_APP_ID=""):
                self.assertEqual(api.get("/api/social-oauth/instagram/start/").status_code, 503)

    def _callback(self, platform, state=None, **extra):
        state = state or signing.dumps({"u": self.user.id, "p": platform}, salt="social-oauth")
        return APIClient().get(f"/api/social-oauth/{platform}/callback/", {"code": "abc", "state": state, **extra})

    def test_callback_creates_connected_account_and_encrypted_token(self):
        exp = timezone.now() + timedelta(hours=24)
        ts = TokenSet("ACCESS", "REFRESH", exp, exp + timedelta(days=300), "video.list", "open1")
        from apps.analytics.platforms.base import AccountData
        with mock.patch.object(TikTokClient, "exchange_code", return_value=ts), \
             mock.patch.object(TikTokClient, "fetch_profile", return_value=AccountData("open1", "nepfan", "", 1234, avg_engagement_rate=0.05)):
            r = self._callback("tiktok")
        self.assertEqual(r.status_code, 302)
        self.assertIn("connected=tiktok", r["Location"])
        acc = SocialAccount.objects.get(platform="tiktok", external_id="open1")
        self.assertEqual((acc.user_id, acc.status, acc.followers), (self.user.id, "connected", 1234))
        self.assertEqual(acc.token.access_token, "ACCESS")
        from django.db import connection
        with connection.cursor() as c:
            c.execute("select access_token from social_tokens")
            self.assertNotIn("ACCESS", c.fetchone()[0])              # stored encrypted

    def test_callback_rejects_bad_state_and_other_users_account(self):
        self.assertIn("error=", self._callback("tiktok", state="garbage")["Location"])
        other = User.objects.create_user(email="o@x.com", username="oth", password="pass12345!", role="creator")
        SocialAccount.objects.create(user=other, platform="tiktok", external_id="open1", handle="x", status="connected")
        from apps.analytics.platforms.base import AccountData
        ts = TokenSet("A", "R", timezone.now() + timedelta(hours=1), None, "", "open1")
        with mock.patch.object(TikTokClient, "exchange_code", return_value=ts), \
             mock.patch.object(TikTokClient, "fetch_profile", return_value=AccountData("open1", "n", "", 1)):
            r = self._callback("tiktok")
        self.assertIn("already+connected", r["Location"])
        self.assertEqual(SocialToken.objects.count(), 0)

    def test_token_refresh(self):
        acc = SocialAccount.objects.create(user=self.user, platform="tiktok", external_id="o", handle="h", status="connected")
        SocialToken.objects.create(account=acc, access_token="OLD", refresh_token="R1", expires_at=timezone.now() + timedelta(minutes=2))
        new = TokenSet("NEW", "R2", timezone.now() + timedelta(hours=24), None)
        acc.refresh_from_db()
        with mock.patch.object(TikTokClient, "refresh", return_value=new) as rf:
            self.assertEqual(access_token_for(get_client("tiktok"), acc), "NEW")
        rf.assert_called_once_with("OLD", "R1")
        acc.token.refresh_from_db()
        self.assertEqual((acc.token.access_token, acc.token.refresh_token), ("NEW", "R2"))

    def test_manual_account_without_token_falls_back(self):
        from apps.analytics.platforms.base import PlatformNotConfigured
        acc = SocialAccount.objects.create(user=self.user, platform="instagram", external_id="m", handle="h", status="connected")
        with self.assertRaises(PlatformNotConfigured):
            get_client("instagram").fetch_posts_for_account(acc, ["ABC"])
