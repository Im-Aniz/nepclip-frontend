import secrets

from django.conf import settings
from django.db import models

from apps.core.fields import EncryptedTextField
from apps.core.models import TimeStamped


class CreatorProfile(TimeStamped):
    user = models.OneToOneField(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="creator_profile")
    full_name = models.CharField(max_length=120)
    bio = models.TextField(blank=True)
    niches = models.JSONField(default=list, blank=True)  # e.g. ["gaming", "comedy"]
    city = models.CharField(max_length=80, blank=True)

    class Meta:
        db_table = "creator_profiles"

    def __str__(self):
        return self.full_name


class SocialAccount(TimeStamped):
    class Platform(models.TextChoices):
        YOUTUBE = "youtube", "YouTube"
        TIKTOK = "tiktok", "TikTok"
        INSTAGRAM = "instagram", "Instagram"
        FACEBOOK = "facebook", "Facebook"

    class Status(models.TextChoices):
        PENDING = "pending", "Pending verification"
        CONNECTED = "connected", "Connected"
        SUSPENDED = "suspended", "Suspended"

    user = models.ForeignKey(settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name="social_accounts")
    platform = models.CharField(max_length=12, choices=Platform.choices)
    handle = models.CharField(max_length=120)
    external_id = models.CharField(max_length=120, db_index=True)  # YouTube channel id etc.
    profile_url = models.URLField(blank=True)
    followers = models.PositiveIntegerField(default=0)
    avg_engagement_rate = models.DecimalField(max_digits=6, decimal_places=4, default=0)  # (likes+comments)/views
    account_created_at = models.DateTimeField(null=True, blank=True)
    is_platform_verified = models.BooleanField(default=False)   # e.g. YouTube verified badge, when known
    status = models.CharField(max_length=10, choices=Status.choices, default=Status.PENDING)
    verification_code = models.CharField(max_length=20, blank=True)
    verified_at = models.DateTimeField(null=True, blank=True)
    last_synced_at = models.DateTimeField(null=True, blank=True)

    class Meta:
        db_table = "social_accounts"
        constraints = [models.UniqueConstraint(fields=["platform", "external_id"], name="uniq_platform_external")]
        indexes = [models.Index(fields=["user", "platform"])]

    @staticmethod
    def new_code():
        return "NEPCLIP-" + secrets.token_hex(3).upper()

    @property
    def is_verified_owner(self):
        return self.status == self.Status.CONNECTED


class SocialToken(TimeStamped):
    """OAuth authorisation for accounts connected through TikTok / Instagram login. Tokens are encrypted at rest."""
    account = models.OneToOneField(SocialAccount, on_delete=models.CASCADE, related_name="token")
    access_token = EncryptedTextField()
    refresh_token = EncryptedTextField(blank=True, default="")
    expires_at = models.DateTimeField(null=True, blank=True)
    refresh_expires_at = models.DateTimeField(null=True, blank=True)
    scopes = models.CharField(max_length=300, blank=True)

    class Meta:
        db_table = "social_tokens"
