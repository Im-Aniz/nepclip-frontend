from django.db import IntegrityError
from django.db.models import Count, Q, Sum
from django.utils import timezone
from rest_framework import mixins, viewsets
from rest_framework.decorators import action, api_view, permission_classes
from rest_framework.exceptions import ValidationError
from rest_framework.generics import RetrieveUpdateAPIView
from rest_framework.response import Response

from apps.adminpanel.services import get_setting
from apps.analytics.platforms.base import PlatformError, PlatformNotConfigured
from apps.analytics.platforms.registry import get_client
from apps.analytics.services.tokens import access_token_for
from apps.analytics.services.stats import earnings_timeseries, views_timeseries
from apps.campaigns.models import CampaignCreator
from apps.core.permissions import IsCreator
from apps.earnings.models import Earning
from apps.submissions.models import Submission

from .models import CreatorProfile, SocialAccount
from .serializers import ConnectAccountSerializer, CreatorProfileSerializer, SocialAccountSerializer


class ProfileView(RetrieveUpdateAPIView):
    permission_classes = [IsCreator]
    serializer_class = CreatorProfileSerializer

    def get_object(self):
        return self.request.user.creator_profile


class SocialAccountViewSet(mixins.ListModelMixin, mixins.CreateModelMixin, mixins.DestroyModelMixin, viewsets.GenericViewSet):
    permission_classes = [IsCreator]
    serializer_class = SocialAccountSerializer
    pagination_class = None

    def get_queryset(self):
        return SocialAccount.objects.filter(user=self.request.user)

    def create(self, request, *a, **kw):
        s = ConnectAccountSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        platform, handle = s.validated_data["platform"], s.validated_data["handle"].strip()
        if platform not in get_setting("supported_platforms"):
            raise ValidationError({"platform": "Platform not supported yet."})
        client = get_client(platform)
        try:
            data = client.fetch_account(handle)
            ext_id, handle_out, url, followers = data.external_id, data.handle, data.profile_url, data.followers
            extra = {"avg_engagement_rate": data.avg_engagement_rate, "account_created_at": data.created_at}
        except PlatformNotConfigured:
            if platform == "youtube":
                return Response({"detail": "YouTube isn't configured on this server yet (missing YOUTUBE_API_KEY)."}, status=503)
            ext_id, handle_out, url, followers, extra = handle.lstrip("@").lower(), handle, "", 0, {}   # manual verification
        except PlatformError as e:
            raise ValidationError({"handle": str(e)})
        try:
            acc = SocialAccount.objects.create(user=request.user, platform=platform, handle=handle_out, external_id=ext_id,
                                               profile_url=url, followers=followers, verification_code=SocialAccount.new_code(),
                                               last_synced_at=timezone.now(), **extra)
        except IntegrityError:
            raise ValidationError({"handle": "This account is already connected to a NepClip profile."})
        return Response(SocialAccountSerializer(acc).data, status=201)

    @action(detail=True, methods=["post"])
    def verify(self, request, pk=None):
        acc = self.get_object()
        if acc.status == "connected":
            return Response(SocialAccountSerializer(acc).data)
        if acc.platform != "youtube":
            return Response({"detail": "This platform is verified manually by our team."}, status=400)
        try:
            data = get_client("youtube").fetch_account(acc.profile_url or acc.handle)
        except PlatformNotConfigured:
            return Response({"detail": "YouTube isn't configured on this server."}, status=503)
        except PlatformError as e:
            raise ValidationError({"detail": str(e)})
        if acc.verification_code not in data.description:
            return Response({"detail": f"We couldn't find {acc.verification_code} in your channel description. It can take a few minutes to update."}, status=400)
        acc.status, acc.verified_at, acc.followers = "connected", timezone.now(), data.followers
        acc.avg_engagement_rate, acc.account_created_at, acc.last_synced_at = data.avg_engagement_rate, data.created_at, timezone.now()
        acc.save()
        return Response(SocialAccountSerializer(acc).data)

    @action(detail=True, methods=["post"])
    def refresh(self, request, pk=None):
        acc = self.get_object()
        client = get_client(acc.platform)
        try:
            if getattr(client, "oauth", False) and hasattr(acc, "token"):
                data = client.fetch_profile(access_token_for(client, acc))
            else:
                data = client.fetch_account(acc.profile_url or acc.handle)
        except PlatformError as e:
            raise ValidationError({"detail": str(e)})
        acc.followers, acc.avg_engagement_rate, acc.last_synced_at = data.followers, data.avg_engagement_rate, timezone.now()
        acc.save()
        return Response(SocialAccountSerializer(acc).data)


@api_view(["GET"])
@permission_classes([IsCreator])
def creator_dashboard(request):
    u = request.user
    subs = Submission.objects.filter(creator=u)
    agg = subs.aggregate(
        total=Count("id"), approved=Count("id", filter=Q(status__in=["approved", "paid"])), rejected=Count("id", filter=Q(status="rejected")),
        pending=Count("id", filter=Q(status__in=["pending", "under_review", "fraud_review"])),
        views=Sum("views"), eligible=Sum("eligible_views"))
    w = u.wallet
    per_campaign = (subs.values("campaign__name").annotate(views=Sum("views"), earned=Sum("reward_total")).order_by("-earned")[:6])
    return Response({
        "wallet": {"available": w.available, "pending": w.pending, "lifetime": w.lifetime_earnings, "withdrawn": w.withdrawn},
        "total_submitted": agg["total"], "approved": agg["approved"], "rejected": agg["rejected"], "pending": agg["pending"],
        "total_views": agg["views"] or 0, "eligible_views": agg["eligible"] or 0,
        "active_campaigns": CampaignCreator.objects.filter(creator=u, status="active", campaign__status="published").count(),
        "views_series": views_timeseries(subs, 30), "earnings_series": earnings_timeseries(Earning.objects.filter(creator=u), 30),
        "campaign_performance": [{"name": r["campaign__name"], "views": r["views"] or 0, "earned": float(r["earned"] or 0)} for r in per_campaign],
    })
