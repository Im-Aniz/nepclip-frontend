"""Connect a creator's TikTok / Instagram account through the platform's own login (OAuth).

1. The creator page calls GET /api/social-oauth/<platform>/start/ and is sent to the platform's login screen.
2. The platform redirects back to GET /api/social-oauth/<platform>/callback/ (register this URL in your developer app).
3. We exchange the code, read the profile, save the account as connected and store the encrypted tokens,
   then send the creator back to the website.
"""
from urllib.parse import urlencode

from django.conf import settings
from django.core import signing
from django.http import Http404, HttpResponseRedirect
from django.utils import timezone
from rest_framework.decorators import api_view, authentication_classes, permission_classes
from rest_framework.permissions import AllowAny
from rest_framework.response import Response

from apps.accounts.models import User
from apps.adminpanel.services import get_setting
from apps.analytics.platforms.base import PlatformError
from apps.analytics.platforms.registry import get_client
from apps.core.permissions import IsCreator

from .models import SocialAccount, SocialToken

SALT = "social-oauth"
STATE_MAX_AGE = 15 * 60


def _client(platform):
    try:
        c = get_client(platform)
    except PlatformError:
        raise Http404
    if not getattr(c, "oauth", False):
        raise Http404
    return c


@api_view(["GET"])
@permission_classes([IsCreator])
def oauth_start(request, platform):
    client = _client(platform)
    if platform not in get_setting("supported_platforms"):
        return Response({"detail": "Platform not supported yet."}, status=400)
    if not client.configured:
        return Response({"detail": f"{platform.title()} login isn't set up on this server yet."}, status=503)
    state = signing.dumps({"u": request.user.id, "p": platform}, salt=SALT)
    return Response({"url": client.authorize_url(state)})


@api_view(["GET"])
@authentication_classes([])
@permission_classes([AllowAny])
def oauth_callback(request, platform):
    client = _client(platform)
    base = settings.FRONTEND_URL.rstrip("/") + "/creator/accounts"

    def back(**q):
        return HttpResponseRedirect(f"{base}?{urlencode(q)}")

    if request.GET.get("error") or request.GET.get("error_reason"):
        return back(error=f"{platform.title()} login was cancelled.")
    code = request.GET.get("code")
    try:
        st = signing.loads(request.GET.get("state", ""), salt=SALT, max_age=STATE_MAX_AGE)
    except signing.BadSignature:
        return back(error="That connect link expired. Please try again.")
    user = User.objects.filter(pk=st.get("u"), role="creator").first()
    if not code or not user or st.get("p") != platform:
        return back(error="Couldn't complete the connection. Please try again.")

    try:
        tokens = client.exchange_code(code)
        profile = client.fetch_profile(tokens.access_token, tokens.external_id)
    except PlatformError as e:
        return back(error=str(e)[:160])

    acc = SocialAccount.objects.filter(platform=platform, external_id=profile.external_id).first()
    if acc and acc.user_id != user.id:
        return back(error="This account is already connected to another NepClip profile.")
    now = timezone.now()
    if not acc:
        acc = SocialAccount(user=user, platform=platform, external_id=profile.external_id, verification_code=SocialAccount.new_code())
    acc.handle, acc.profile_url, acc.followers = profile.handle, profile.profile_url, profile.followers
    acc.avg_engagement_rate, acc.is_platform_verified = profile.avg_engagement_rate, profile.verified_badge
    acc.status, acc.verified_at, acc.last_synced_at = "connected", acc.verified_at or now, now
    acc.save()
    SocialToken.objects.update_or_create(account=acc, defaults={
        "access_token": tokens.access_token, "refresh_token": tokens.refresh_token, "expires_at": tokens.expires_at,
        "refresh_expires_at": tokens.refresh_expires_at, "scopes": tokens.scopes})
    return back(connected=platform)
