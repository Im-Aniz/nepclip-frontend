from django.utils import timezone

from apps.analytics.models import PerformanceSnapshot
from apps.analytics.platforms.base import PlatformError
from apps.analytics.platforms.registry import get_client
from apps.analytics.services.metrics import eligible_views_for


def record_snapshot(sub, m, now=None, source="api"):
    """Append a snapshot (never overwrites history) and refresh the denormalised latest metrics."""
    now = now or timezone.now()
    eng = ((m.likes + m.comments) / m.views) if m.views else 0
    if not m.available:  # keep last known counts; record availability
        m.views, m.likes, m.comments = sub.views, sub.likes, sub.comments
    snap = PerformanceSnapshot.objects.create(
        submission=sub, views=m.views, likes=m.likes, comments=m.comments, shares=m.shares, engagement_rate=round(eng, 4),
        followers=sub.social_account.followers if sub.social_account else None, available=m.available, source=source, captured_at=now)
    sub.views, sub.likes, sub.comments, sub.shares = m.views, m.likes, m.comments, m.shares
    sub.post_available, sub.last_checked_at = m.available, now
    sub.eligible_views = eligible_views_for(sub, now.date())
    sub.save(update_fields=["views", "likes", "comments", "shares", "post_available", "last_checked_at", "eligible_views", "updated_at"])
    return snap


def _apply(subs, metrics):
    """Record snapshots for each submission, then fraud-score and settle it."""
    from apps.earnings.services.settle import settle_submission
    from apps.fraud.services.evaluate import evaluate_submission
    done = 0
    for s in subs:
        m = metrics.get(s.external_post_id)
        if not m:
            continue
        record_snapshot(s, m)
        s.refresh_from_db()
        evaluate_submission(s)
        s.refresh_from_db()
        if s.status in ("approved", "paid"):
            settle_submission(s.pk)
        done += 1
    return done


def sync_platform(platform, subs):
    """Fetch metrics for many submissions of one platform (batched), then fraud-score and settle each."""
    client = get_client(platform)
    if getattr(client, "oauth", False):
        # TikTok / Instagram: metrics come from each creator's own authorised account, so fetch per account.
        by_account = {}
        for s in subs:
            if s.social_account_id:
                by_account.setdefault(s.social_account_id, []).append(s)
        done = 0
        for group in by_account.values():
            try:
                metrics = client.fetch_posts_for_account(group[0].social_account, [s.external_post_id for s in group])
            except PlatformError:            # not configured, no saved login, or token revoked: leave for manual review
                continue
            done += _apply(group, metrics)
        return done
    try:
        metrics = client.fetch_posts([s.external_post_id for s in subs])
    except PlatformError:
        return 0
    return _apply(subs, metrics)
