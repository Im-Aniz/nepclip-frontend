"""Platform adapter interface. Add TikTok/Instagram/Facebook by implementing PlatformClient."""
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from typing import Optional


class PlatformError(Exception):
    pass


class PlatformNotConfigured(PlatformError):
    pass


@dataclass
class PostMetrics:
    post_id: str
    available: bool = True               # False if deleted/private
    views: int = 0
    likes: int = 0
    comments: int = 0
    shares: int = 0
    title: str = ""
    description: str = ""
    channel_id: str = ""
    duration_seconds: Optional[int] = None
    posted_at: Optional[datetime] = None
    is_vertical: Optional[bool] = None   # None = unknown
    tags: list = field(default_factory=list)


@dataclass
class AccountData:
    external_id: str
    handle: str
    profile_url: str
    followers: int
    description: str = ""
    created_at: Optional[datetime] = None
    country: str = ""
    avg_engagement_rate: float = 0.0
    verified_badge: bool = False


@dataclass
class TokenSet:
    """Result of an OAuth code exchange or refresh."""
    access_token: str
    refresh_token: str = ""
    expires_at: Optional[datetime] = None
    refresh_expires_at: Optional[datetime] = None
    scopes: str = ""
    external_id: str = ""


class PlatformClient(ABC):
    platform = ""
    oauth = False                              # True: metrics need the creator's own authorization (TikTok, Instagram)
    refresh_margin = timedelta(minutes=10)     # refresh the access token when it expires within this window

    def fetch_posts_for_account(self, account, post_ids: list[str]) -> dict[str, PostMetrics]:
        """Metrics for posts owned by a connected SocialAccount. API-key platforms ignore the account."""
        return self.fetch_posts(post_ids)

    @property
    @abstractmethod
    def configured(self) -> bool: ...

    @abstractmethod
    def parse_post_url(self, url: str) -> Optional[str]:
        """Return the platform post id, or None if the URL is not a valid post URL for this platform."""

    @abstractmethod
    def fetch_posts(self, post_ids: list[str]) -> dict[str, PostMetrics]: ...

    @abstractmethod
    def fetch_account(self, handle_or_url: str) -> AccountData: ...
