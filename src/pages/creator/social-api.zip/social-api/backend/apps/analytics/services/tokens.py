from django.utils import timezone

from apps.analytics.platforms.base import PlatformError, PlatformNotConfigured


def access_token_for(client, account) -> str:
    """The account's access token, refreshed first if it is about to expire.
    Raises PlatformNotConfigured when the account has no saved authorisation (e.g. it was added manually),
    so callers fall back to manual review exactly as before."""
    if not client.configured:
        raise PlatformNotConfigured(f"{client.platform} API is not configured on the server.")
    tok = getattr(account, "token", None)
    if tok is None:
        raise PlatformNotConfigured("This account isn't connected through the platform login.")
    now = timezone.now()
    if tok.expires_at and tok.expires_at - now < client.refresh_margin:
        try:
            ts = client.refresh(tok.access_token, tok.refresh_token)
        except PlatformError:
            if tok.expires_at <= now:
                raise PlatformError("Authorisation expired. Ask the creator to reconnect this account.")
            return tok.access_token               # still valid; try again on the next sync
        tok.access_token = ts.access_token
        tok.refresh_token = ts.refresh_token or tok.refresh_token
        tok.expires_at, tok.refresh_expires_at = ts.expires_at, ts.refresh_expires_at or tok.refresh_expires_at
        tok.save()
    return tok.access_token
