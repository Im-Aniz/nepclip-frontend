from .base import PlatformError
from .instagram import InstagramClient
from .stubs import FacebookClient
from .tiktok import TikTokClient
from .youtube import YouTubeClient

_CLIENTS = {c.platform: c for c in (YouTubeClient(), TikTokClient(), InstagramClient(), FacebookClient())}


def get_client(platform: str):
    try:
        return _CLIENTS[platform]
    except KeyError:
        raise PlatformError(f"Unsupported platform: {platform}")
