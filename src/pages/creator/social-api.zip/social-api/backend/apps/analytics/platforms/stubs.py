"""Facebook adapter (TikTok and Instagram live in tiktok.py / instagram.py): interface is wired, API calls are intentionally NOT faked.
Until you obtain API approval and implement these, submissions on these platforms are validated by URL pattern
and routed to manual review; metrics must be entered/verified by admin."""
import re
from typing import Optional

from .base import AccountData, PlatformClient, PlatformNotConfigured


class _Unconfigured(PlatformClient):
    patterns: list = []
    env_hint = ""

    @property
    def configured(self):
        return False

    def parse_post_url(self, url: str) -> Optional[str]:
        for p in self.patterns:
            m = re.match(p, (url or "").strip())
            if m:
                return m.group(1)
        return None

    def fetch_posts(self, post_ids):
        raise PlatformNotConfigured(f"{self.platform} metrics API not configured. {self.env_hint}")

    def fetch_account(self, handle_or_url):
        raise PlatformNotConfigured(f"{self.platform} account API not configured. {self.env_hint}")


class FacebookClient(_Unconfigured):
    platform = "facebook"
    env_hint = "Facebook Graph API credentials required."
    patterns = [r"^https?://(?:www\.|m\.)?facebook\.com/(?:reel|watch|[\w.]+/videos)/(\d+)(?:[/?#].*)?$"]
