"""TikTok adapter (Login Kit + Display API v2).

Unlike YouTube, TikTok only returns metrics for videos owned by a creator who has authorised our app, so every
call here uses that creator's access token. /video/query/ only ever returns the token owner's own videos, which also
proves the submitted video belongs to the connected account.
Needs TIKTOK_CLIENT_KEY / TIKTOK_CLIENT_SECRET and the scopes in TIKTOK_SCOPES to be approved for your app.
"""
import re
from datetime import datetime, timedelta, timezone as dt_tz
from typing import Optional
from urllib.parse import urlencode

import requests
from django.conf import settings
from django.utils import timezone

from .base import AccountData, PlatformClient, PlatformError, PlatformNotConfigured, PostMetrics, TokenSet

AUTH_URL = "https://www.tiktok.com/v2/auth/authorize/"
API = "https://open.tiktokapis.com/v2"
POST_PATTERN = re.compile(r"^https?://(?:www\.)?tiktok\.com/@[\w.]+/video/(\d+)(?:[/?#].*)?$")
VIDEO_FIELDS = "id,title,video_description,duration,view_count,like_count,comment_count,share_count,create_time"


def _hashtags(text: str) -> list:
    return [t.lower() for t in re.findall(r"#(\w+)", text or "")]


class TikTokClient(PlatformClient):
    platform = "tiktok"
    oauth = True
    refresh_margin = timedelta(minutes=10)     # access tokens last ~24h

    @property
    def configured(self):
        return bool(settings.TIKTOK_CLIENT_KEY and settings.TIKTOK_CLIENT_SECRET)

    def parse_post_url(self, url: str) -> Optional[str]:
        m = POST_PATTERN.match((url or "").strip())
        return m.group(1) if m else None

    # ---- OAuth -------------------------------------------------------------------------------------------------
    def authorize_url(self, state: str) -> str:
        q = {"client_key": settings.TIKTOK_CLIENT_KEY, "scope": settings.TIKTOK_SCOPES, "response_type": "code",
             "redirect_uri": settings.TIKTOK_REDIRECT_URI, "state": state}
        return f"{AUTH_URL}?{urlencode(q)}"

    def _request(self, method, path, *, token=None, **kw):
        if not self.configured:
            raise PlatformNotConfigured("TIKTOK_CLIENT_KEY / TIKTOK_CLIENT_SECRET are not set on the server.")
        headers = {"Authorization": f"Bearer {token}"} if token else {}
        try:
            r = requests.request(method, f"{API}{path}", headers=headers, timeout=20, **kw)
        except requests.RequestException as e:
            raise PlatformError(f"TikTok request failed: {e}") from e
        try:
            body = r.json()
        except ValueError:
            raise PlatformError(f"TikTok returned an unexpected response ({r.status_code}).")
        err = body.get("error")
        if isinstance(err, dict):                       # data endpoints: {"error": {"code": "ok", "message": ""}}
            if err.get("code") not in (None, "", "ok"):
                raise PlatformError(f"TikTok: {err.get('message') or err.get('code')}")
        elif err:                                       # token endpoint: {"error": "invalid_grant", "error_description": ...}
            raise PlatformError(f"TikTok: {body.get('error_description') or err}")
        if r.status_code >= 400:
            raise PlatformError(f"TikTok API error {r.status_code}.")
        return body

    @staticmethod
    def _tokens(body) -> TokenSet:
        now = timezone.now()
        return TokenSet(
            access_token=body["access_token"], refresh_token=body.get("refresh_token", ""), external_id=body.get("open_id", ""),
            expires_at=now + timedelta(seconds=int(body.get("expires_in", 86400))),
            refresh_expires_at=now + timedelta(seconds=int(body["refresh_expires_in"])) if body.get("refresh_expires_in") else None,
            scopes=body.get("scope", ""))

    def exchange_code(self, code: str) -> TokenSet:
        body = self._request("POST", "/oauth/token/", data={
            "client_key": settings.TIKTOK_CLIENT_KEY, "client_secret": settings.TIKTOK_CLIENT_SECRET, "code": code,
            "grant_type": "authorization_code", "redirect_uri": settings.TIKTOK_REDIRECT_URI})
        if "access_token" not in body:
            raise PlatformError("TikTok didn't return an access token.")
        return self._tokens(body)

    def refresh(self, access_token: str, refresh_token: str) -> TokenSet:
        if not refresh_token:
            raise PlatformError("TikTok authorisation expired. Please reconnect the account.")
        body = self._request("POST", "/oauth/token/", data={
            "client_key": settings.TIKTOK_CLIENT_KEY, "client_secret": settings.TIKTOK_CLIENT_SECRET,
            "grant_type": "refresh_token", "refresh_token": refresh_token})
        if "access_token" not in body:
            raise PlatformError("TikTok authorisation expired. Please reconnect the account.")
        return self._tokens(body)

    # ---- data --------------------------------------------------------------------------------------------------
    def fetch_profile(self, access_token: str, external_id: str = "") -> AccountData:
        scopes = settings.TIKTOK_SCOPES
        fields = ["open_id", "display_name"]
        if "user.info.stats" in scopes:
            fields += ["follower_count", "likes_count", "video_count"]
        if "user.info.profile" in scopes:
            fields += ["username", "profile_deep_link", "is_verified"]
        user = (self._request("GET", "/user/info/", token=access_token, params={"fields": ",".join(fields)}).get("data") or {}).get("user") or {}
        if not user.get("open_id"):
            raise PlatformError("Couldn't read your TikTok profile.")
        eng = self._recent_engagement(access_token) if "video.list" in scopes else 0.0
        return AccountData(
            external_id=user["open_id"], handle=user.get("username") or user.get("display_name") or "TikTok creator",
            profile_url=user.get("profile_deep_link", ""), followers=int(user.get("follower_count") or 0),
            avg_engagement_rate=eng, verified_badge=bool(user.get("is_verified")))

    def _recent_engagement(self, access_token) -> float:
        try:
            body = self._request("POST", "/video/list/", token=access_token, params={"fields": "view_count,like_count,comment_count"}, json={"max_count": 20})
            vids = (body.get("data") or {}).get("videos") or []
            views = sum(int(v.get("view_count") or 0) for v in vids)
            inter = sum(int(v.get("like_count") or 0) + int(v.get("comment_count") or 0) for v in vids)
            return round(inter / views, 4) if views else 0.0
        except PlatformError:
            return 0.0

    def fetch_posts_with_token(self, access_token: str, owner_id: str, post_ids: list[str]) -> dict[str, PostMetrics]:
        out = {}
        for i in range(0, len(post_ids), 20):            # API max 20 ids per call
            chunk = post_ids[i:i + 20]
            body = self._request("POST", "/video/query/", token=access_token, params={"fields": VIDEO_FIELDS}, json={"filters": {"video_ids": chunk}})
            for v in (body.get("data") or {}).get("videos") or []:
                desc = v.get("video_description") or v.get("title") or ""
                ts = v.get("create_time")
                out[str(v["id"])] = PostMetrics(
                    post_id=str(v["id"]), available=True, views=int(v.get("view_count") or 0), likes=int(v.get("like_count") or 0),
                    comments=int(v.get("comment_count") or 0), shares=int(v.get("share_count") or 0), title=v.get("title") or "",
                    description=desc, channel_id=owner_id, duration_seconds=v.get("duration"),
                    posted_at=datetime.fromtimestamp(int(ts), dt_tz.utc) if ts else None, is_vertical=None, tags=_hashtags(desc))
            for pid in chunk:
                if pid not in out:                       # deleted, private, or not owned by this creator
                    out[pid] = PostMetrics(post_id=pid, available=False)
        return out

    def fetch_posts_for_account(self, account, post_ids):
        from apps.analytics.services.tokens import access_token_for
        return self.fetch_posts_with_token(access_token_for(self, account), account.external_id, post_ids)

    def fetch_posts(self, post_ids):
        raise PlatformNotConfigured("TikTok metrics need the creator's connected account.")

    def fetch_account(self, handle_or_url):
        if not self.configured:
            raise PlatformNotConfigured("Set TIKTOK_CLIENT_KEY / TIKTOK_CLIENT_SECRET after TikTok API approval.")
        raise PlatformError("Use the Connect with TikTok button to link this account.")
