"""Instagram adapter (Instagram API with Instagram Login). Works for Business / Creator accounts only.

Like TikTok, metrics are only available for media owned by an account that authorised our app. Instagram post URLs
contain a shortcode, not the Graph media id, so we match the shortcode against the owner's /me/media permalinks.
Needs INSTAGRAM_APP_ID / INSTAGRAM_APP_SECRET (the *Instagram* app credentials under Instagram > API setup).
"""
import re
from datetime import timedelta
from typing import Optional
from urllib.parse import urlencode

import requests
from django.conf import settings
from django.utils import timezone
from django.utils.dateparse import parse_datetime

from .base import AccountData, PlatformClient, PlatformError, PlatformNotConfigured, PostMetrics, TokenSet

AUTH_URL = "https://www.instagram.com/oauth/authorize"
TOKEN_URL = "https://api.instagram.com/oauth/access_token"
GRAPH = "https://graph.instagram.com"
VERSION = "v22.0"
POST_PATTERN = re.compile(r"^https?://(?:www\.)?instagram\.com/(?:[\w.]+/)?(?:reel|reels|p|tv)/([\w-]+)(?:[/?#].*)?$")
MEDIA_FIELDS = "id,permalink,caption,media_type,media_product_type,timestamp,like_count,comments_count"
MAX_PAGES = 8        # x50 = the owner's latest 400 posts


def _shortcode(permalink: str) -> Optional[str]:
    m = POST_PATTERN.match(permalink or "")
    return m.group(1) if m else None


def _when(s):
    if not s:
        return None
    return parse_datetime(s) or parse_datetime(re.sub(r"([+-]\d\d)(\d\d)$", r"\1:\2", s))


class InstagramClient(PlatformClient):
    platform = "instagram"
    oauth = True
    refresh_margin = timedelta(days=7)         # long-lived tokens last 60 days and are refreshed in place

    @property
    def configured(self):
        return bool(settings.INSTAGRAM_APP_ID and settings.INSTAGRAM_APP_SECRET)

    def parse_post_url(self, url: str) -> Optional[str]:
        m = POST_PATTERN.match((url or "").strip())
        return m.group(1) if m else None

    # ---- OAuth -------------------------------------------------------------------------------------------------
    def authorize_url(self, state: str) -> str:
        q = {"client_id": settings.INSTAGRAM_APP_ID, "redirect_uri": settings.INSTAGRAM_REDIRECT_URI, "response_type": "code",
             "scope": settings.INSTAGRAM_SCOPES, "state": state}
        return f"{AUTH_URL}?{urlencode(q)}"

    def _call(self, method, url, **kw):
        if not self.configured:
            raise PlatformNotConfigured("INSTAGRAM_APP_ID / INSTAGRAM_APP_SECRET are not set on the server.")
        try:
            r = requests.request(method, url, timeout=20, **kw)
        except requests.RequestException as e:
            raise PlatformError(f"Instagram request failed: {e}") from e
        try:
            body = r.json()
        except ValueError:
            raise PlatformError(f"Instagram returned an unexpected response ({r.status_code}).")
        err = body.get("error") if isinstance(body, dict) else None
        if err or r.status_code >= 400:
            msg = (err.get("message") if isinstance(err, dict) else None) or (body.get("error_message") if isinstance(body, dict) else None) or f"error {r.status_code}"
            raise PlatformError(f"Instagram: {msg}")
        return body

    @staticmethod
    def _expiry(body):
        return timezone.now() + timedelta(seconds=int(body.get("expires_in") or 60 * 86400))

    def exchange_code(self, code: str) -> TokenSet:
        code = (code or "").split("#")[0]
        body = self._call("POST", TOKEN_URL, data={
            "client_id": settings.INSTAGRAM_APP_ID, "client_secret": settings.INSTAGRAM_APP_SECRET, "grant_type": "authorization_code",
            "redirect_uri": settings.INSTAGRAM_REDIRECT_URI, "code": code})
        if isinstance(body.get("data"), list) and body["data"]:
            body = body["data"][0]
        short = body.get("access_token")
        if not short:
            raise PlatformError("Instagram didn't return an access token.")
        long = self._call("GET", f"{GRAPH}/access_token", params={"grant_type": "ig_exchange_token", "client_secret": settings.INSTAGRAM_APP_SECRET, "access_token": short})
        return TokenSet(access_token=long["access_token"], expires_at=self._expiry(long), scopes=settings.INSTAGRAM_SCOPES, external_id=str(body.get("user_id", "")))

    def refresh(self, access_token: str, refresh_token: str = "") -> TokenSet:
        body = self._call("GET", f"{GRAPH}/refresh_access_token", params={"grant_type": "ig_refresh_token", "access_token": access_token})
        return TokenSet(access_token=body["access_token"], expires_at=self._expiry(body), scopes=settings.INSTAGRAM_SCOPES)

    # ---- data --------------------------------------------------------------------------------------------------
    def fetch_profile(self, access_token: str, external_id: str = "") -> AccountData:
        me = self._call("GET", f"{GRAPH}/{VERSION}/me", params={"fields": "user_id,username,account_type,followers_count,media_count", "access_token": access_token})
        uid = str(me.get("user_id") or me.get("id") or "")
        if not uid:
            raise PlatformError("Couldn't read your Instagram profile.")
        if me.get("account_type") not in (None, "BUSINESS", "MEDIA_CREATOR"):
            raise PlatformError("Only Instagram Business or Creator accounts can be connected. Switch your account type in Instagram settings.")
        user, followers = me.get("username", ""), int(me.get("followers_count") or 0)
        return AccountData(external_id=uid, handle=f"@{user}" if user else uid, profile_url=f"https://www.instagram.com/{user}/" if user else "",
                           followers=followers, avg_engagement_rate=self._recent_engagement(access_token, followers))

    def _recent_engagement(self, access_token, followers) -> float:
        """Average (likes + comments) per recent post, relative to followers; per-post views need one insights call each."""
        try:
            items = self._call("GET", f"{GRAPH}/{VERSION}/me/media", params={"fields": "like_count,comments_count", "limit": 12, "access_token": access_token}).get("data", [])
        except PlatformError:
            return 0.0
        if not items or not followers:
            return 0.0
        inter = sum(int(i.get("like_count") or 0) + int(i.get("comments_count") or 0) for i in items)
        return round(inter / len(items) / followers, 4)

    def _media_index(self, token, wanted: set) -> dict:
        found, pages = {}, 0
        url, params = f"{GRAPH}/{VERSION}/me/media", {"fields": MEDIA_FIELDS, "limit": 50, "access_token": token}
        while url and pages < MAX_PAGES:
            body = self._call("GET", url, params=params)
            pages, params = pages + 1, None                  # the "next" url already carries every parameter
            for it in body.get("data", []):
                sc = _shortcode(it.get("permalink", ""))
                if sc in wanted:
                    found[sc] = it
            if len(found) == len(wanted):
                break
            url = (body.get("paging") or {}).get("next")
        return found

    def _insights(self, token, media_id) -> dict:
        for metrics in ("views,shares", "views"):
            try:
                body = self._call("GET", f"{GRAPH}/{VERSION}/{media_id}/insights", params={"metric": metrics, "access_token": token})
            except PlatformError:
                continue
            out = {}
            for d in body.get("data", []):
                v = (d.get("values") or [{}])[0].get("value")
                if v is None:
                    v = (d.get("total_value") or {}).get("value")
                out[d.get("name")] = int(v or 0)
            return out
        return {}

    def fetch_posts_with_token(self, access_token: str, owner_id: str, post_ids: list[str]) -> dict[str, PostMetrics]:
        index = self._media_index(access_token, set(post_ids))
        out = {}
        for pid in post_ids:
            it = index.get(pid)
            if not it:                                           # deleted, not a Business/Creator post, or older than the lookback
                out[pid] = PostMetrics(post_id=pid, available=False)
                continue
            ins = self._insights(access_token, it["id"])
            cap = it.get("caption") or ""
            out[pid] = PostMetrics(
                post_id=pid, available=True, views=ins.get("views", 0), likes=int(it.get("like_count") or 0), comments=int(it.get("comments_count") or 0),
                shares=ins.get("shares", 0), title=cap[:100], description=cap, channel_id=owner_id, posted_at=_when(it.get("timestamp")),
                is_vertical=True if it.get("media_product_type") == "REELS" else None, tags=[t.lower() for t in re.findall(r"#(\w+)", cap)])
        return out

    def fetch_posts_for_account(self, account, post_ids):
        from apps.analytics.services.tokens import access_token_for
        return self.fetch_posts_with_token(access_token_for(self, account), account.external_id, post_ids)

    def fetch_posts(self, post_ids):
        raise PlatformNotConfigured("Instagram metrics need the creator's connected account.")

    def fetch_account(self, handle_or_url):
        if not self.configured:
            raise PlatformNotConfigured("Set INSTAGRAM_APP_ID / INSTAGRAM_APP_SECRET (Instagram API with Instagram Login).")
        raise PlatformError("Use the Connect with Instagram button to link this account.")
